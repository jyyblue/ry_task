module.exports = {
  projects: ['<rootDir>/extension', '<rootDir>/packages/*'],
};
