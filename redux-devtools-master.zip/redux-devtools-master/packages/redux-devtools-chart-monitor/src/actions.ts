export const TOGGLE_VISIBILITY =
  '@@redux-devtools-log-monitor/TOGGLE_VISIBILITY';
interface ToggleVisibilityAction {
  type: typeof TOGGLE_VISIBILITY;
}
export type ChartMonitorAction = ToggleVisibilityAction;
