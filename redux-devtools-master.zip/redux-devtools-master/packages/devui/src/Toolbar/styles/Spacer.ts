import styled from 'styled-components';

const Spacer = styled.div`
  flex-grow: 1;
`;

export default Spacer;
