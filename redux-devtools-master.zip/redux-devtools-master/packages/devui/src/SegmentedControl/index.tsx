export { default } from './SegmentedControl';
