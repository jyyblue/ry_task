export const items = [
  {
    name: 'Menu Item 1',
  },
  {
    name: 'Menu Item 2',
  },
  {
    name: 'Menu Item 3',
  },
];
