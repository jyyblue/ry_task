export const options = [
  { value: 'one', label: 'One' },
  { value: 'two', label: 'Two' },
  { value: 'hundred', label: 'One hundred' },
];
