# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [0.1.0](https://github.com/reduxjs/redux-devtools/compare/d3-state-visualizer-tree-example@0.0.2...d3-state-visualizer-tree-example@0.1.0) (2021-03-06)

### Features

- **d3-state-visualizer:** convert example to TypeScript ([#641](https://github.com/reduxjs/redux-devtools/issues/641)) ([300b60a](https://github.com/reduxjs/redux-devtools/commit/300b60a8b1f92a6d7c78510a1bea304490aa23be))

## [0.0.2](https://github.com/reduxjs/redux-devtools/compare/d3-state-visualizer-tree-example@0.0.1...d3-state-visualizer-tree-example@0.0.2) (2020-09-07)

**Note:** Version bump only for package d3-state-visualizer-tree-example

## 0.0.1 (2020-08-14)

**Note:** Version bump only for package d3-state-visualizer-tree-example
