import prependClass from './prependClass';
import functor from './functor';

export default {
  prependClass,
  functor,
};
