export const DATA_TYPE_KEY = Symbol.for('__serializedType__');
export const DATA_REF_KEY = Symbol.for('__serializedRef__');
