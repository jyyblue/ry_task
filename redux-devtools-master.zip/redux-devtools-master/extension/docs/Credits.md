# Credits

- Built using [Crossbuilder](https://github.com/zalmoxisus/crossbuilder) boilerplate.
- Includes [Dan Abramov](https://github.com/gaearon)'s [redux-devtools](https://github.com/gaearon/redux-devtools) and the following monitors:
  - [Log Monitor](https://github.com/gaearon/redux-devtools-log-monitor)
  - [Inspector](https://github.com/alexkuz/redux-devtools-inspector)
  - [Dispatch](https://github.com/YoruNoHikage/redux-devtools-dispatch)
  - [Slider](https://github.com/calesce/redux-slider-monitor)
  - [Chart](https://github.com/romseguy/redux-devtools-chart-monitor)
- [The logo icon](https://github.com/reactjs/redux/issues/151) made by [Keith Yong](https://github.com/keithyong) .
- Examples from [Redux](https://github.com/rackt/redux/tree/master/examples).
