import {createContext} from 'react';

const ThemeContext = createContext(null);

export default ThemeContext;
