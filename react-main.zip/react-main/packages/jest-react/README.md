# `jest-react`

Jest matchers and utilities for testing React Test Renderer.