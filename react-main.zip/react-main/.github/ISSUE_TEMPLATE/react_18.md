---
name: "💬 React 18"
about: Bug reports, questions, and general feedback about React 18
title: 'React 18 '
labels: 'Type: Discussion, React 18'

---

<!--
  Ask a question or share feedback about the React 18 release here.
-->
